# forge-cdp-manager

Cross-process **CDP surface leases** and **connect serialization** for shared operator Edge profiles (`:9222`, `:9223`, …).

Used by **forge-cockpit-web**, **forge-knowledge-assistant**, **forge-lcdl** attach helpers, and CLI harnesses — not tied to LCDL task orchestration.

## Install

```bash
cd forge-cdp-manager
pip install -e .
```

From sibling consumers (typical Forge workspace layout):

```bash
pip install -e ../forge-cdp-manager
```

## CLI

```bash
forge-cdp-lease list [--cdp-url URL]
forge-cdp-lease probe outlook_mail [--cdp-url URL]
forge-cdp-lease release-stale [--force]
```

## Environment

| Variable | Legacy alias | Default | Meaning |
|----------|--------------|---------|---------|
| `FORGE_CDP_MANAGER_ENABLED` | `FORGE_LCDL_CDP_SESSION_MANAGER` | `0` | Enable cross-process leases |
| `FORGE_CDP_MANAGER_LOCK_DIR` | `FORGE_LCDL_CDP_LOCK_DIR` | `~/.cache/forge-cdp/leases` | Shared lock root |
| `FORGE_CDP_MANAGER_LEASE_TTL_S` | `FORGE_LCDL_CDP_LEASE_TTL_S` | `7200` | Stale reclaim TTL |

See [docs/CDP-SESSION-MANAGER.md](docs/CDP-SESSION-MANAGER.md).

## Architecture (not a service)

**forge-cdp-manager is a Python library**, not a daemon. There is nothing to `systemctl start`.

- Leases are **file locks** under `~/.cache/forge-cdp/leases` (or `FORGE_CDP_MANAGER_LOCK_DIR`).
- Every consumer process (Cockpit, KA, CLI) imports the library and acquires/releases leases locally.
- **No standalone HTTP server** and **no bearer token** on this package itself.

### REST (via Cockpit only)

When **forge-cockpit-web** is running, local HTTP endpoints delegate to this library:

| Method | Path | Auth |
|--------|------|------|
| `GET` | `/api/cdp/leases` | None (localhost trust model, same as other Cockpit API routes) |
| `POST` | `/api/cdp/release-stale?force=true` | None |

Example (Cockpit on port 9775):

```bash
curl -sS http://127.0.0.1:9775/api/cdp/leases
curl -sS -X POST 'http://127.0.0.1:9775/api/cdp/release-stale?force=true' \
  -H 'Content-Type: application/json' -d '{}'
```

Shell self-heal (`forge-cockpit-web/scripts/lib/cdp-tab-runners.sh`) uses these endpoints **or** the `forge-cdp-lease` CLI.

Remote bearer-protected lease admin would be a Cockpit hardening task (Fleet-style), not part of this library.

