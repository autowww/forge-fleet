---
title: "CDP session manager"
description: "Cross-process Edge CDP surface leases and connect serialization."
audience: developer,operator,agent
status: beta
tags: [edge, cdp, playwright, cockpit, knowledge-assistant]
---

# CDP session manager

**Package:** `forge-cdp-manager` — module `forge_cdp_manager`

## Purpose

When **Cockpit**, **Knowledge Assistant**, and **CLI harnesses** share one operator Edge profile (`http://127.0.0.1:9222`), in-process threading locks are not enough. This package provides:

1. **Surface leases** — one exclusive worker per tab family (mail, Teams, People, …).
2. **Connect slot** — brief global serialization during CDP attach handshakes.
3. **Stale reclaim** — metadata + flock cleanup when a holder process exits or TTL expires.

## Coordinated bind-tab

`POST /v1/sessions/{id}/bind-tab` attaches the manager process Playwright session to the operator CDP tab (`target_id` optional). Registers `cdp-manager:{session_id}` for `POST /v1/flows/run` and LCDL composite tasks. **Connect-only** — no tab close or Edge quit.

LCDL **tasks** and consumer **orchestration** are unchanged. Hosts acquire leases **before** attach and register pages for `run_task` as today.

## Surfaces

| Surface key | Typical tab | Picker |
|-------------|-------------|--------|
| `outlook_mail` | OWA mail inbox | `pick_owa_cdp_page_target` |
| `outlook_calendar` | OWA calendar month | `pick_calendar_cdp_page_target` |
| `teams` | Teams v2 | `pick_teams_cdp_page_target` |
| `outlook_people` | OWA People | `pick_outlook_people_cdp_page_target` |
| `linkedin` | LinkedIn profile | `pick_linkedin_cdp_page_target` |
| `sharepoint` | SharePoint library | KA `pick_sharepoint_cdp_page_target` |
| `crm_portfolio` | Dynamics list | `pick_crm_portfolio_cdp_page_target` |
| `_connect` | *(attach only)* | connect slot |

Leases are namespaced by CDP origin (`127.0.0.1_9222` vs `127.0.0.1_9223`).

## Usage

```python
from forge_cdp_manager import (
    SURFACE_OUTLOOK_MAIL,
    cdp_connect_slot,
    cdp_surface_session,
)

cdp_url = "http://127.0.0.1:9222"

with cdp_surface_session(SURFACE_OUTLOOK_MAIL, cdp_url=cdp_url, owner="sync-42"):
    with cdp_connect_slot(cdp_url=cdp_url):
        # attach_generic_edge_cdp / connect_owa_page_via_selective_cdp
        ...
```

## Environment

| Variable | Legacy alias | Default | Meaning |
|----------|--------------|---------|---------|
| `FORGE_CDP_MANAGER_ENABLED` | `FORGE_LCDL_CDP_SESSION_MANAGER` | `0` | Enable cross-process leases |
| `FORGE_CDP_MANAGER_LOCK_DIR` | `FORGE_LCDL_CDP_LOCK_DIR` | `~/.cache/forge-cdp/leases` | Shared lock root |
| `FORGE_CDP_MANAGER_LEASE_TTL_S` | `FORGE_LCDL_CDP_LEASE_TTL_S` | `7200` | Reclaim metadata when holder exceeds TTL |
| `COCKPIT_PARALLEL_INGEST_RUNNERS` | `1` | Default on — set `0` or use `COCKPIT_SEQUENTIAL_INGEST_RUNNERS=1` for legacy single-runner behavior |

## CLI

```bash
forge-cdp-lease list [--cdp-url URL]
forge-cdp-lease probe outlook_mail [--cdp-url URL]
forge-cdp-lease release-stale [--cdp-url URL] [--force]
```

## Stale reclaim

1. Holder PID no longer running → flock released by kernel; metadata cleaned on next `release-stale`.
2. TTL exceeded → treated as stale for reclaim.
3. `release_all_held_leases()` — in-process cancel (Cockpit `cancel-all`).

## Related

- forge-lcdl [EDGE-CDP-ATTACH.md](../../forge-lcdl/docs/playwright/EDGE-CDP-ATTACH.md) — selective page attach
- forge-cockpit-web [parallel-cdp-ingest-runners.md](../../forge-cockpit-web/docs/parallel-cdp-ingest-runners.md)
