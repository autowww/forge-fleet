# forge-cdp-manager

Cross-process **CDP surface leases**, **surface registry**, and optional **HTTP control plane** for shared operator Edge profiles (`:9222`, `:9223`, …).

Used by **forge-cockpit-web**, **forge-knowledge-assistant**, **forge-lcdl** attach helpers, and CLI harnesses.

## Install

```bash
cd forge-cdp-manager
pip install -e ".[serve]"
```

Library-only (no HTTP):

```bash
pip install -e .
```

## CLI

```bash
forge-cdp-lease list [--cdp-url URL]
forge-cdp-lease probe outlook_mail [--cdp-url URL]
forge-cdp-lease release-stale [--force]
forge-cdp-serve --host 127.0.0.1 --port 18770
```

## HTTP control plane

```bash
export FORGE_CDP_MANAGER_ENABLED=1
forge-cdp-serve
curl -sS http://127.0.0.1:18770/health
curl -sS http://127.0.0.1:18770/v1/fleet
```

Set `FORGE_CDP_MANAGER_URL=http://127.0.0.1:18770` in Cockpit/bash for HTTP client mode (library fallback when unset).

OpenAPI: [docs/openapi.yaml](docs/openapi.yaml)  
Security: [docs/SECURITY.md](docs/SECURITY.md)  
AutomationFlow: [docs/AUTOMATION-FLOW-v1.md](docs/AUTOMATION-FLOW-v1.md)

## Environment

| Variable | Default | Meaning |
|----------|---------|---------|
| `FORGE_CDP_MANAGER_ENABLED` | `0` | Enable cross-process flock leases |
| `FORGE_CDP_MANAGER_URL` | *(unset)* | HTTP client base URL for consumers |
| `FORGE_CDP_MANAGER_PORT` | `18770` | Daemon listen port |
| `FORGE_CDP_MANAGER_LOCK_DIR` | `~/.cache/forge-cdp/leases` | Flock storage |
| `FORGE_CDP_MANAGER_REGISTRY_STRICT` | `0` | Reject unknown surfaces at acquire |

See [docs/CDP-SESSION-MANAGER.md](docs/CDP-SESSION-MANAGER.md).  
Operator runbook: [docs/CDP-OPERATOR-RUNBOOK.md](docs/CDP-OPERATOR-RUNBOOK.md).

## Architecture

- **Library** — flock leases + connect slot (`forge_cdp_manager.session`); always available offline.
- **Registry** — surface descriptors in `builtin_surfaces/` + `~/.config/forge-cdp/surfaces/*.json`.
- **Daemon** — optional FastAPI app: registry, leases, sessions, SSE progress, LCDL gateway, AutomationFlow.

Cockpit `:9775` `/api/cdp/*` remains a compatibility proxy when `FORGE_CDP_MANAGER_URL` is set.
